# SAST – Signal Anomaly and Security Tracking

A modern, fully responsive analytics dashboard inspired by Cloudflare Radar, focused on traffic monitoring, anomaly detection, security intelligence, and connectivity analytics.

---

## 📁 File / Folder Structure

```
sast/
├── index.html              ← Main application entry point
├── css/
│   └── style.css           ← Master stylesheet (dark/light theme, responsive)
├── js/
│   └── app.js              ← Application logic (charts, auth, navigation, theme)
├── php/
│   ├── config.php          ← MySQL database config & PDO connection
│   ├── auth.php            ← Authentication API (login, signup, logout, check)
│   └── api.php             ← Analytics data API (all dashboard sections)
├── db/
│   └── schema.sql          ← MySQL schema + seed/dummy data
└── README.md               ← This file
```

---

## 🚀 Setup Instructions

### Option A — Static Demo (no server needed)
Simply open `index.html` in any modern browser. The app detects that the PHP backend is unavailable and automatically falls back to inline dummy data. All charts, metrics, and navigation work perfectly.

### Option B — Full Stack (PHP + MySQL)
1. **Install prerequisites:** PHP 8.0+, MySQL 8.0+, a web server (Apache / Nginx)
2. **Database setup:**
   ```bash
   mysql -u root -p < db/schema.sql
   ```
   > ⚠️ Update the dummy user password hashes in `schema.sql` using PHP's `password_hash('your_password', PASSWORD_BCRYPT)` before inserting.
3. **Configure database credentials** in `php/config.php`
4. **Serve the project** from your web server's document root
5. Open `http://localhost/` (or your configured URL)

---

## ✨ Features

| Feature | Status |
|---|---|
| Dark / Light theme toggle | ✅ Persists across sessions |
| Login / Signup / Logout | ✅ Full auth flow |
| Overview Dashboard | ✅ 7 metric cards + RPS chart + HTTP methods |
| Traffic → Overview | ✅ Volume chart + device pie |
| Traffic → Adoption | ✅ Browsers, protocols, mobile OS, user agents |
| Traffic → AI Insights | ✅ Bot table, best practices, robots.txt agents |
| Security → App Layer | ✅ Timeline, attack types, threat intel |
| Security → Network Layer | ✅ Timeline, DDoS breakdown, network intel |
| Connectivity | ✅ IQI, speed chart, latency, insights |
| Tools → Data Explorer | ✅ Filterable request log table |
| Tools → Reports | ✅ Monthly/quarterly/annual with download |
| Responsive Mobile Layout | ✅ Bottom nav, hamburger, touch-friendly |
| Animated Metric Counters | ✅ Smooth count-up on page load |
| Chart.js Integration | ✅ 12 unique charts across all sections |

---

## 🎨 Design System

- **Colors:** Teal primary (`#00c9a7`), Violet accent (`#6c63ff`), semantic danger/warning/info/success
- **Typography:** Inter (sans) + JetBrains Mono (code/numbers)
- **Cards:** 12px border-radius, subtle borders, hover lift effect
- **Animations:** CSS `fadeSlideUp` for page transitions, JS `easeOutCubic` for counters
- **Theme:** CSS custom properties (`--clr-*`, `--bg-*`, `--txt-*`) — switch by setting `data-theme` on `<html>`

---

## 📊 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3 (Grid, Flexbox, Variables), Vanilla JS |
| Charts | Chart.js v4 (CDN) |
| Backend | PHP 8.0+ (REST API) |
| Database | MySQL 8.0+ |
| Auth | bcrypt password hashing, Bearer token sessions |

---

## 🔧 Customization

- **Add real data:** Replace the dummy generators in `js/app.js` (`generateOverviewDummy`, etc.) with `fetch()` calls to your `php/api.php` endpoints.
- **Extend the schema:** Add new tables in `db/schema.sql` and corresponding queries in `php/api.php`.
- **New pages:** Add a `<section id="mypage" class="page-section">` in `index.html`, a nav link with `data-page="mypage"`, and handle rendering in `app.js`.
